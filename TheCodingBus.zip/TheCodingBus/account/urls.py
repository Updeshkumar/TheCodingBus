from django.contrib import admin

app_name = "account"

urlpatterns = [  
]